package dev.guldeniz.cv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvApplicationTests {

	@Test
	void contextLoads() {
	}

}
